#!/bin/bash

# Update package list
echo "Updating package list..."
sudo apt update -y
sudo apt install nano -y

# Install required packages
echo "Installing software-properties-common..."
sudo apt install -y software-properties-common

# Add MariaDB repository key
echo "Adding MariaDB repository key..."
sudo apt-key adv --fetch-keys 'https://mariadb.org/mariadb_release_signing_key.asc'

# Add MariaDB repository
echo "Adding MariaDB repository..."
sudo add-apt-repository 'deb [arch=amd64,arm64,ppc64el] https://mariadb.mirror.liquidtelecom.com/repo/10.6/ubuntu focal main'

# Update package list again and install MariaDB
echo "Updating package list and installing MariaDB..."
sudo apt update && sudo apt install -y mariadb-server mariadb-client

# Check MariaDB version
echo "Checking MariaDB version..."
mariadb --version

# Check MariaDB service status
echo "Checking MariaDB service status..."
if systemctl is-active --quiet mariadb; then
    echo "MariaDB is running."
else
    echo "MariaDB is not running. Attempting to start..."
    sudo systemctl start mariadb
    if systemctl is-active --quiet mariadb; then
        echo "MariaDB started successfully."
    else
        echo "Failed to start MariaDB."
        exit 1
    fi
fi

# Enable MariaDB to start on boot
echo "Enabling MariaDB service to start on boot..."
sudo systemctl enable mariadb

# Run MySQL secure installation
echo "Running mysql_secure_installation..."
sudo mysql_secure_installation <<EOF

Y
root@2024
root@2024
Y
Y
Y
Y
EOF

# Configure MariaDB to listen on a specific IP address
echo "Configuring MariaDB to listen on 192.168.10.10..."
sudo sed -i 's/^bind-address\s*=.*$/# bind-address = 192.168.10.10/' /etc/mysql/mariadb.conf.d/50-server.cnf
sudo systemctl restart mariadb

# Install iptables and iptables-persistent
echo "Installing iptables and iptables-persistent..."
sudo apt-get install -y iptables iptables-persistent

# Install and configure UFW
echo "Installing UFW..."
sudo apt-get install -y ufw

# Disable IPv6 in UFW
echo "Disabling IPv6 in UFW..."
sudo sed -i 's/^IPV6=.*$/IPV6=no/' /etc/default/ufw

# Restart UFW
echo "Restarting UFW..."
sudo ufw disable
sudo ufw enable

# Allow specific IPs to access MariaDB
echo "Configuring UFW rules for MariaDB access..."
sudo ufw allow from 192.168.10.10 to any port 3306
sudo ufw allow from 192.168.10.11 to any port 3306
sudo ufw allow from 192.168.10.12 to any port 3306
sudo ufw allow from 192.168.10.13 to any port 3306

echo "MariaDB installation and configuration completed successfully."