#!/bin/bash

# Script to install Nginx as a Reverse Proxy and Load Balancer

# Define the domain name for your WordPress site
DOMAINNAME="wordpress.labo.cloudns.be"

# Update packages and dependencies
echo "Updating packages and dependencies..."
sudo apt update -y
sudo apt upgrade -y
sudo apt install nano -y
echo "Update completed."

# Install Nginx
echo "Installing Nginx..."
sudo apt install nginx -y
sudo systemctl enable nginx
sudo systemctl start nginx
echo "Nginx installation completed."

# Check Nginx configuration and reload
sudo nginx -t
sudo systemctl reload nginx

# Go to /etc/nginx/sites-available, remove the default configuration, and create wordpress.conf
echo "Configuring Nginx for load balancing..."
sudo rm /etc/nginx/sites-available/default
sudo touch /etc/nginx/sites-available/wordpress.conf

# Fill wordpress.conf with the load balancing configuration
cat <<EOL | sudo tee /etc/nginx/sites-available/wordpress.conf
upstream wordpress_backend {
    server 192.168.10.11;  # IP of server 1
    server 192.168.10.12;  # IP of server 2
}

server {
    listen 80;
    listen [::]:80;
    server_name $DOMAINNAME;

    location / {
        proxy_pass http://wordpress_backend;
        proxy_http_version 1.1;
        proxy_cache_bypass \$http_upgrade;
        add_header 'Content-Security-Policy' 'upgrade-insecure-requests';
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;
        proxy_set_header X-Forwarded-Port \$server_port;
    }

    # Uncomment the following lines to set caching for static files
    # location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
    #     expires 30d;
    # }
}
EOL

# Go to /etc/nginx/sites-enabled, remove the default configuration, and create a symbolic link for wordpress.conf
sudo rm /etc/nginx/sites-enabled/default
sudo ln -s /etc/nginx/sites-available/wordpress.conf /etc/nginx/sites-enabled/wordpress.conf

# Check Nginx configuration and reload
echo "Testing Nginx configuration..."
sudo nginx -t
if [ $? -eq 0 ]; then
    echo "Nginx configuration is valid. Reloading Nginx..."
    sudo systemctl reload nginx
    echo "Nginx reloaded successfully."
else
    echo "Nginx configuration test failed. Please check the configuration for errors."
    exit 1
fi

echo "Nginx is now configured as a reverse proxy and load balancer for your WordPress site."
