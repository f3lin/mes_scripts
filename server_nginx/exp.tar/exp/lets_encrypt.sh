#!/bin/bash

# Usage function to display help
usage() {
    echo "Usage: $0 -d domainname"
    exit 1
}

# Parse command line arguments
while getopts ":d:" opt; do
    case ${opt} in
        d )
            domainname=$OPTARG
            ;;
        \? )
            usage
            ;;
    esac
done

# Check if all arguments are provided
if [ -z "$domainname" ]; then
    usage
fi

#Installation de Let's Encrypt
echo "Installation de Let's Encrypt..."
sudo apt-get install python3-certbot-nginx -y

# Configuration de Let's Encrypt
echo "Configuration de Let's Encrypt..."
sudo certbot --nginx -d $domainname --email alex@jmetio.de --agree-tos --non-interactive

# Vérification du certificat
if [ $? -ne 0 ]; then
    echo "Erreur: Certbot n'a pas pu obtenir un certificat SSL."
    exit 1
fi
