#!/bin/bash

# Définir les chemins des fichiers à inclure dans l'archive
FILES=(
    "/var/log/nginx/access.log"
    "/var/log/nginx/error.log"
    "/etc/nginx/sites-available/wordpress.conf"
)

# Définir le nom de l'archive tar
BACKUP_DIR="/vagrant/backup"
BACKUP_FILE="$HOME/admin.tar.gz"

# Créer le répertoire de sauvegarde s'il n'existe pas
sudo mkdir -p $BACKUP_DIR

# Supprimer l'archive tar existante
sudo rm -f $BACKUP_FILE

# Créer la nouvelle archive tar avec les fichiers spécifiés
sudo tar -czvf $BACKUP_FILE "${FILES[@]}"

# Vérifier si la création de l'archive a réussi
if [ $? -eq 0 ]; then
    echo "Sauvegarde créée avec succès : $BACKUP_FILE"
else
    echo "Erreur lors de la création de la sauvegarde"
    exit 1
fi

# Copier l'archive vers le répertoire de sauvegarde
sudo cp $BACKUP_FILE $BACKUP_DIR
