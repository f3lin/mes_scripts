#!/bin/bash

# Définir les chemins des fichiers à inclure dans l'archive
FILES=(
    "/etc/letsencrypt/live/wordpress.labo.cloudns.be/fullchain.pem"
    "/etc/letsencrypt/live/wordpress.labo.cloudns.be/privkey.pem"
    "/etc/letsencrypt/options-ssl-nginx.conf"
    "/etc/letsencrypt/ssl-dhparams.pem"
    "/etc/letsencrypt/ssl-dhparams.pem"
)

# Définir le nom de l'archive tar
BACKUP_DIR="/home/ubuntu/backup"
BACKUP_FILE="$HOME/backup.tar.gz"

# Créer le répertoire de sauvegarde s'il n'existe pas
mkdir -p $BACKUP_DIR

# Supprimer l'archive tar existante
rm -f $BACKUP_FILE

# Créer la nouvelle archive tar avec les fichiers spécifiés
tar -czvf $BACKUP_FILE "${FILES[@]}"

# Vérifier si la création de l'archive a réussi
if [ $? -eq 0 ]; then
    echo "Sauvegarde créée avec succès : $BACKUP_FILE"
else
    echo "Erreur lors de la création de la sauvegarde"
    exit 1
fi

# Copier l'archive vers le répertoire de sauvegarde
sudo cp $BACKUP_FILE $BACKUP_DIR

# Fin du script
