#!/bin/bash

# Chemin de sauvegarde
BACKUP_DIR="/vagrant/backup"

BACKUP_FILE="$$HOME/db_backup"

# Vérifier et créer le répertoire de sauvegarde si nécessaire
echo "Vérification du répertoire $BACKUP_FILE..."
# Vérifier et créer le répertoire de sauvegarde si nécessaire
if [ ! -d "$BACKUP_FILE" ]; then
    mkdir -p "$BACKUP_FILE"
    if [ $? -ne 0 ]; then
        exit 1
    fi
fi

# Assurer que l'utilisateur actuel est propriétaire du répertoire de sauvegarde
sudo chown -R $USER:$USER $BACKUP_FILE

# Donner les permissions d'écriture au propriétaire pour le répertoire de sauvegarde
chmod u+w $BACKUP_FILE

# Fonction pour créer les sauvegardes
create_backup() {
    # Sauvegarde de la base de données MariaDB
    sudo mysqldump -u wordpress wordpress -pwordpress@2024 > "$BACKUP_FILE/wordpress_backup_$(date +"%Y-%m-%d_%H-%M-%S").sql"
}

# Créer une sauvegarde immédiatement
create_backup

sudo cp -r $BACKUP_FILE $BACKUP_DIR