#!/bin/bash

# Script d'installation LEMP pour Nginx, PHP 8.2, et WordPress


# Usage function to display help
usage() {
    echo "Usage: $0 -d DOMAINNAME"
    exit 1
}

# Parse command line arguments
while getopts ":d:" opt; do
    case ${opt} in
        d )
            DOMAINNAME=$OPTARG
            ;;
        \? )
            usage
            ;;
    esac
done

# Check if all arguments are provided
if [ -z "$DOMAINNAME" ]; then
    usage
fi

# Mettre à jour les paquets et les dépendances
echo "Mise à jour des paquets et des dépendances..."
sudo apt update && sudo apt upgrade -y
sudo apt install nano -y
echo "Mise à jour terminée."

# Vérification du statut de Nginx
echo "Vérification du statut de Nginx..."
if sudo systemctl status nginx | grep "active (running)"; then
    echo "Nginx est en cours d'exécution."
else
    echo "Erreur: Nginx n'a pas démarré correctement."
    exit 1
fi

# Add repository for PHP 8
echo "Adding repository for PHP 8..."
sudo apt update
sudo apt install software-properties-common
sudo add-apt-repository ppa:ondrej/php

# Mettre à jour les listes de paquets
sudo apt update

# Installer PHP 8.2 et les extensions couramment utilisées
sudo apt install -y \
    php8.2-fpm \
    php8.2-common \
    php8.2-mysql \
    php8.2-xml \
    php8.2-xmlrpc \
    php8.2-curl \
    php8.2-gd \
    php8.2-imagick \
    php8.2-cli \
    php8.2-dev \
    php8.2-imap \
    php8.2-mbstring \
    php8.2-soap \
    php8.2-zip \
    php8.2-bcmath

# Modifier la configuration de PHP-FPM pour désactiver cgi.fix_pathinfo
sudo sed -i 's/;cgi.fix_pathinfo=1/cgi.fix_pathinfo=0/g' /etc/php/8.2/fpm/php.ini

# Redémarrer le service PHP-FPM pour appliquer les modifications de configuration
sudo service php8.2-fpm restart

# Afficher un message de confirmation
echo "Installation et configuration de PHP 8.2 terminées avec succès."

# Vérification de la version de PHP
echo "Vérification de la version de PHP..."
php -v | grep "PHP 8.2"
if [ $? -ne 0 ]; then
    echo "Erreur: PHP 8.2 n'a pas été installé correctement."
    exit 1
fi
echo "PHP 8.2 est installé."

# Configuration de PHP
echo "Configuration de PHP..."
sudo sed -i 's/;cgi.fix_pathinfo=1/cgi.fix_pathinfo=0/' /etc/php/8.2/fpm/php.ini
sudo sed -i 's/upload_max_filesize = .*/upload_max_filesize = 128M/' /etc/php/8.2/fpm/php.ini
sudo sed -i 's/post_max_size = .*/post_max_size = 128M/' /etc/php/8.2/fpm/php.ini
sudo sed -i 's/memory_limit = .*/memory_limit = 512M/' /etc/php/8.2/fpm/php.ini
sudo sed -i 's/max_execution_time = .*/max_execution_time = 120/' /etc/php/8.2/fpm/php.ini

# Redémarrer PHP-FPM
echo "Redémarrage de PHP-FPM..."
sudo systemctl restart php8.2-fpm

# Vérification du statut de PHP-FPM
echo "Vérification du statut de PHP-FPM..."
if sudo systemctl status php8.2-fpm | grep "active (running)"; then
    echo "PHP-FPM est en cours d'exécution."
else
    echo "Erreur: PHP-FPM n'a pas démarré correctement."
    exit 1
fi

# Installation de WordPress
echo "Installation de WordPress..."
sudo wget -O /var/www/html/latest.tar.gz https://wordpress.org/latest.tar.gz
sudo tar -zxvf /var/www/html/latest.tar.gz -C /var/www/html
sudo mv /var/www/html/wordpress/wp-config-sample.php /var/www/html/wordpress/wp-config.php
sudo rm -rf /var/www/html/latest.tar.gz

# Configuration de WordPress
echo "Configuration de WordPress..."
sudo sed -i "s/database_name_here/wordpress/" /var/www/html/wordpress/wp-config.php
sudo sed -i "s/username_here/wordpress/" /var/www/html/wordpress/wp-config.php
sudo sed -i "s/password_here/wordpress@2024/" /var/www/html/wordpress/wp-config.php
sudo sed -i "s/localhost/192.168.10.13/" /var/www/html/wordpress/wp-config.php

# Permissions pour WordPress
echo "Configuration des permissions pour WordPress..."
sudo chown -R www-data:www-data /var/www/html/wordpress
sudo chmod -R 755 /var/www/html/wordpress

# Configuration Nginx pour WordPress
echo "Configuration de Nginx pour WordPress..."
sudo bash -c 'cat <<EOL > /etc/nginx/conf.d/wordpress.conf
server {
    listen 80;
    root /var/www/html/wordpress;
    index index.php index.html index.htm;
    server_name '$DOMAINNAME';
    client_max_body_size 500M;
    location / {
        try_files \$uri \$uri/ /index.php?\$args;
    }
    location = /favicon.ico {
        log_not_found off;
        access_log off;
    }
    location ~* \.(js|css|png|jpg|jpeg|gif|ico)$ {
        expires max;
        log_not_found off;
    }
    location = /robots.txt {
        allow all;
        log_not_found off;
        access_log off;
    }
    location ~ \.php$ {
         include snippets/fastcgi-php.conf;
         fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
         fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
         include fastcgi_params;
    }
}
EOL'

# Validation de la configuration Nginx
echo "Validation de la configuration Nginx..."
sudo nginx -t
if [ $? -ne 0 ]; then
    echo "Erreur: La configuration Nginx est invalide."
    exit 1
fi

# Redémarrage de Nginx
echo "Redémarrage de Nginx..."
sudo systemctl restart nginx

# Redémarrer PHP-FPM
echo "Redémarrage de PHP-FPM..."
sudo systemctl restart php8.2-fpm

# Vérification du statut de Nginx
echo "Vérification du statut de Nginx..."
if sudo systemctl status nginx | grep "active (running)"; then
    echo "Nginx est en cours d'exécution."
else
    echo "Erreur: Nginx n'a pas redémarré correctement."
    exit 1
fi

echo "Installation LEMP et WordPress terminée avec succès!"