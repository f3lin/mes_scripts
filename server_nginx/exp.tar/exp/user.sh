#!/bin/bash

# Check MariaDB version
echo "Checking MariaDB version..."
mariadb --version

# Check MariaDB service status
echo "Checking MariaDB service status..."
if systemctl is-active --quiet mariadb; then
    echo "MariaDB is running."
else
    echo "MariaDB is not running. Attempting to start..."
    sudo systemctl start mariadb
    if systemctl is-active --quiet mariadb; then
        echo "MariaDB started successfully."
    else
        echo "Failed to start MariaDB."
        exit 1
    fi
fi

# Log in to MariaDB as root
echo "Logging in to MariaDB as root..."
sudo mariadb -u root -p <<EOF

# Create admin user
CREATE USER 'admin'@'192.168.10.10' IDENTIFIED BY 'admin@2024';
GRANT ALL PRIVILEGES ON *.* TO 'admin'@'192.168.10.10';

# Create wordpress user
CREATE USER 'wordpress'@'192.168.10.%' IDENTIFIED BY 'wordpress@2024';
GRANT ALL PRIVILEGES ON wordpress.* TO 'wordpress'@'192.168.10.%';
REVOKE DROP ON wordpress.* FROM 'wordpress'@'192.168.10.%';

# Flush privileges
FLUSH PRIVILEGES;

# Create wordpress database
CREATE DATABASE wordpress;

# Controle: Check if everything went well
SELECT User FROM mysql.user;
SHOW DATABASES;
SHOW GRANTS FOR 'admin'@'192.168.10.10';
SHOW GRANTS FOR 'wordpress'@'192.168.10.%';

EOF

echo "MariaDB setup complete!"